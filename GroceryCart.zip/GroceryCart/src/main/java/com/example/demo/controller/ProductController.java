package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.ProductDetails;
import com.example.demo.services.ProductService;

@Controller
@ResponseBody
public class ProductController {
	@Autowired
	ProductService pservice;

	@GetMapping("/addProduct")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addProduct");
		return modelAndView;
	}

	@PostMapping("/addproduct1")
	public ModelAndView addProduct(ProductDetails product) {
		ModelAndView modelAndView = new ModelAndView();
		System.out.println(product);
		int affectedRows = pservice.addProduct(product);
		if (affectedRows == 1) {
			modelAndView.setViewName("dashboard");
					} else {
			modelAndView.setViewName("addProduct");
			modelAndView.addObject("result", "Product Not Added! Sorry");
		}
		return modelAndView;
	}

	@PostMapping("/viewproduct")
	public ModelAndView getproduct() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("viewproduct");
		modelAndView.addObject("product",pservice.displayProduct());
		return modelAndView;
	}
	@GetMapping("/productdetails")
	public ModelAndView productdetails() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("productdetails");
		modelAndView.addObject("product",pservice.displayProduct());
		return modelAndView;
	}
	@GetMapping("/booking")
	public ModelAndView booking(@RequestParam("prodName") String prodName,@RequestParam("price") int price,@RequestParam("category") String category) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("booking");
		modelAndView.addObject("prodName",prodName);
		modelAndView.addObject("price",price);
		modelAndView.addObject("category",category);
		return modelAndView;
	}

	@GetMapping("/deleteproduct")
	public ModelAndView delete() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("deleteproduct");
		return modelAndView;
	}
	@GetMapping("/successbk")
	public ModelAndView success() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("successbk");
		return modelAndView;
	}


}
